﻿namespace DemoExamProject
{
    partial class MaterialCard
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbTypeMaterialName = new System.Windows.Forms.Label();
            this.lbPackageQuantity = new System.Windows.Forms.Label();
            this.lbStockQuantity = new System.Windows.Forms.Label();
            this.lbPriceUnit = new System.Windows.Forms.Label();
            this.lbBatchPrice = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.поставщикиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbTypeMaterialName
            // 
            this.lbTypeMaterialName.AutoSize = true;
            this.lbTypeMaterialName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbTypeMaterialName.Location = new System.Drawing.Point(20, 14);
            this.lbTypeMaterialName.Name = "lbTypeMaterialName";
            this.lbTypeMaterialName.Size = new System.Drawing.Size(307, 25);
            this.lbTypeMaterialName.TabIndex = 0;
            this.lbTypeMaterialName.Text = "Тип | Наименование материала";
            // 
            // lbPackageQuantity
            // 
            this.lbPackageQuantity.AutoSize = true;
            this.lbPackageQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbPackageQuantity.Location = new System.Drawing.Point(21, 39);
            this.lbPackageQuantity.Name = "lbPackageQuantity";
            this.lbPackageQuantity.Size = new System.Drawing.Size(296, 20);
            this.lbPackageQuantity.TabIndex = 1;
            this.lbPackageQuantity.Text = "Минимальное количество: 1000 кг";
            // 
            // lbStockQuantity
            // 
            this.lbStockQuantity.AutoSize = true;
            this.lbStockQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbStockQuantity.Location = new System.Drawing.Point(21, 59);
            this.lbStockQuantity.Name = "lbStockQuantity";
            this.lbStockQuantity.Size = new System.Drawing.Size(267, 20);
            this.lbStockQuantity.TabIndex = 2;
            this.lbStockQuantity.Text = "Количество на складе: 1000 кг";
            // 
            // lbPriceUnit
            // 
            this.lbPriceUnit.AutoSize = true;
            this.lbPriceUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbPriceUnit.Location = new System.Drawing.Point(21, 79);
            this.lbPriceUnit.Name = "lbPriceUnit";
            this.lbPriceUnit.Size = new System.Drawing.Size(325, 20);
            this.lbPriceUnit.TabIndex = 3;
            this.lbPriceUnit.Text = "Цена: 1000 р / Единица измерения: кг";
            // 
            // lbBatchPrice
            // 
            this.lbBatchPrice.AutoSize = true;
            this.lbBatchPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBatchPrice.Location = new System.Drawing.Point(397, 39);
            this.lbBatchPrice.Name = "lbBatchPrice";
            this.lbBatchPrice.Size = new System.Drawing.Size(214, 20);
            this.lbBatchPrice.TabIndex = 4;
            this.lbBatchPrice.Text = "Стоимость партии: 0,0 р";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поставщикиToolStripMenuItem,
            this.редактироватьToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(211, 80);
            // 
            // поставщикиToolStripMenuItem
            // 
            this.поставщикиToolStripMenuItem.Name = "поставщикиToolStripMenuItem";
            this.поставщикиToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.поставщикиToolStripMenuItem.Text = "Поставщики";
            this.поставщикиToolStripMenuItem.Click += new System.EventHandler(this.поставщикиToolStripMenuItem_Click);
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.редактироватьToolStripMenuItem.Text = "Редактировать";
            // 
            // MaterialCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.lbBatchPrice);
            this.Controls.Add(this.lbPriceUnit);
            this.Controls.Add(this.lbStockQuantity);
            this.Controls.Add(this.lbPackageQuantity);
            this.Controls.Add(this.lbTypeMaterialName);
            this.Name = "MaterialCard";
            this.Size = new System.Drawing.Size(725, 111);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbTypeMaterialName;
        private System.Windows.Forms.Label lbPackageQuantity;
        private System.Windows.Forms.Label lbStockQuantity;
        private System.Windows.Forms.Label lbPriceUnit;
        private System.Windows.Forms.Label lbBatchPrice;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem поставщикиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
    }
}
