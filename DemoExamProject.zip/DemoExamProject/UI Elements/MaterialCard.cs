﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoExamProject
{
    public partial class MaterialCard : UserControl
    {
        public event Action<int> EditClick;
        public int materialId;
        public MaterialCard(int materialId, string materialType, string materialName, int minimalQuantity, int storageQuantity, double materialPrice, string materialMeasurement)
        {
            InitializeComponent();
            this.materialId = materialId;
            lbTypeMaterialName.Text = String.Format("{0} | {1}", materialType, materialName);
            lbPackageQuantity.Text = String.Format("Минимальное количество: {0} {1}", minimalQuantity, materialMeasurement);
            lbStockQuantity.Text = String.Format("Количество на складе: {0} {1}", storageQuantity, materialMeasurement);
            lbPriceUnit.Text = String.Format("Цена: {0} р | Единица измерения: {1}", materialPrice, materialMeasurement);
            lbBatchPrice.Text = String.Format("Стоимость партии: {0}", CalculatePurchaseCost(minimalQuantity, storageQuantity, materialPrice));
        }
        public double CalculatePurchaseCost(int minimalQuantity, int storageQuantity, double materialPrice)
        {
            int deficit = Math.Max(0, minimalQuantity - storageQuantity);

            if (deficit < 0)
                return 0.00;
            if (deficit == 0)
                return storageQuantity * materialPrice;

            // Рассчитываем количество упаковок для покрытия дефицита
            int packagesNeeded = (int)Math.Ceiling((double)deficit / minimalQuantity);
            int purchaseQuantity = packagesNeeded * minimalQuantity;

            double cost = purchaseQuantity * materialPrice;
            return Math.Round(Math.Max(0, cost), 3);
        }

        private void поставщикиToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
