﻿using System;
using System.Windows.Forms;

namespace DemoExamProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ShowMaterialsPage();
        }

        private void ShowMaterialsPage()
        {
            pAppPanel.Controls.Clear();

            var materialsPage = new MaterialsPage();
            materialsPage.EditRequested += (materialId) =>
            {
                ShowEditPage(materialId);
            };

            pAppPanel.Controls.Add(materialsPage);
        }

        private void ShowEditPage(int materialId)
        {
            pAppPanel.Controls.Clear();

            var editForm = new MaterialForm(materialId);
            editForm.EditingComplete += () =>
            {
                ShowMaterialsPage();
            };

            pAppPanel.Controls.Add(editForm);
        }
    }
}