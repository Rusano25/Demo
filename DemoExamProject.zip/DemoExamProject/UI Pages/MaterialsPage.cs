﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoExamProject
{
    public partial class MaterialsPage : UserControl
    {
        public event Action<int> EditRequested;
        private string connectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=MosaicDB;Integrated Security=True";
        private ContextMenuStrip materialContextMenu;
        private MaterialCard selectedCard;
        public MaterialsPage()
        {
            InitializeComponent();
            InitializeContextMenu();
            LoadMaterials();
        }

        private void InitializeContextMenu()
        {
            materialContextMenu = new ContextMenuStrip();

            var editItem = new ToolStripMenuItem("Редактировать");
            var suppliersItem = new ToolStripMenuItem("Поставщики");
            editItem.Click += EditMaterial_Click;
            suppliersItem.Click += Suppliers_Click;
            materialContextMenu.Items.AddRange(new ToolStripItem[] { editItem, suppliersItem });
        }

        private void LoadMaterials()
        {
            flpMaterials.Controls.Clear();
            try
            {
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"
                        SELECT m.MaterialId, m.MaterialName, mt.TypeName as MaterialType, 
                               m.UnitCost, m.StockQuantity, m.MinStockQuantity, 
                               m.PackageQuantity, m.UnitOfMeasure
                        FROM materials m
                        JOIN MaterialTypes mt ON m.MaterialTypeId = mt.MaterialTypeId";

                    using (var cmd = new SqlCommand(query, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var card = new MaterialCard(
                                Convert.ToInt32(reader["MaterialId"]),
                                reader["MaterialType"].ToString(),
                                reader["MaterialName"].ToString(),
                                Convert.ToInt32(reader["MinStockQuantity"]),
                                Convert.ToInt32(reader["StockQuantity"]),
                                Convert.ToDouble(reader["UnitCost"]),
                                reader["UnitOfMeasure"].ToString()
                            );

                            card.MouseDown += (s, e) =>
                            {
                                if (e.Button == MouseButtons.Right)
                                {
                                    // Снимаем подсветку со всех карточек
                                    foreach (MaterialCard c in flpMaterials.Controls.OfType<MaterialCard>())
                                    {
                                        c.BackColor = Color.White;
                                        c.BorderStyle = BorderStyle.None;
                                    }

                                    // Подсвечиваем текущую карточку
                                    selectedCard = (MaterialCard)s;
                                    selectedCard.BackColor = Color.LightSkyBlue;
                                    selectedCard.BorderStyle = BorderStyle.FixedSingle;

                                    // Показываем контекстное меню
                                    materialContextMenu.Show(card, e.Location);
                                }
                            };

                            flpMaterials.Controls.Add(card);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Card_MouseDown(object sender, MouseEventArgs e)
        {
        }
        private void EditMaterial_Click(object sender, EventArgs e)
        {
            var selectedCard = flpMaterials.Controls.OfType<MaterialCard>()
                                  .FirstOrDefault(c => c.BackColor == Color.LightSkyBlue);

            if (selectedCard != null)
            {
                EditRequested?.Invoke(selectedCard.materialId);
            }
        }

        private void DeleteMaterial_Click(object sender, EventArgs e)
        {
            var selectedCard = flpMaterials.Controls.OfType<MaterialCard>()
                                  .FirstOrDefault(c => c.BackColor == SystemColors.ControlLight);

            if (selectedCard != null)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить этот материал?",
                    "Подтверждение удаления",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    try
                    {
                        using (var conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            string query = "DELETE FROM materials WHERE MaterialId = @MaterialId";
                            using (var cmd = new SqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@MaterialId", selectedCard.materialId);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        // Удаляем карточку из панели
                        flpMaterials.Controls.Remove(selectedCard);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении материала: {ex.Message}", "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                // Сброс выделения
                selectedCard.BackColor = SystemColors.Control;
            }
        }
        private void Suppliers_Click(object sender, EventArgs e)
        {

        }
    }
}
