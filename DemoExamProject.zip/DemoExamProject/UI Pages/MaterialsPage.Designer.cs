﻿namespace DemoExamProject
{
    partial class MaterialsPage
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.flpMaterials = new System.Windows.Forms.FlowLayoutPanel();
            this.btnAddCard = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // flpMaterials
            // 
            this.flpMaterials.AutoScroll = true;
            this.flpMaterials.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flpMaterials.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpMaterials.Location = new System.Drawing.Point(4, 60);
            this.flpMaterials.Name = "flpMaterials";
            this.flpMaterials.Size = new System.Drawing.Size(764, 371);
            this.flpMaterials.TabIndex = 0;
            this.flpMaterials.WrapContents = false;
            // 
            // btnAddCard
            // 
            this.btnAddCard.Location = new System.Drawing.Point(802, 5);
            this.btnAddCard.Name = "btnAddCard";
            this.btnAddCard.Size = new System.Drawing.Size(77, 49);
            this.btnAddCard.TabIndex = 2;
            this.btnAddCard.Text = "+";
            this.btnAddCard.UseVisualStyleBackColor = true;
            // 
            // MaterialsPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnAddCard);
            this.Controls.Add(this.flpMaterials);
            this.Name = "MaterialsPage";
            this.Size = new System.Drawing.Size(882, 455);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpMaterials;
        private System.Windows.Forms.Button btnAddCard;
    }
}
