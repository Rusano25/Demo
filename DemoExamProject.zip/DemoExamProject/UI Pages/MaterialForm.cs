﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoExamProject
{
    public partial class MaterialForm : UserControl
    {
        public event Action EditingComplete;
        private string connectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=MosaicDB;Integrated Security=True";
        private int? materialId;
        public MaterialForm(int? id = null)
        {
            InitializeComponent();
            materialId = id;
            LoadMaterialTypes();
            if (materialId.HasValue)
            {
                LoadMaterialData(id);
            }
        }
        private void LoadMaterialData(int? id)
        {
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"
                    SELECT MaterialName, MaterialTypeId, UnitCost, StockQuantity, 
                           MinStockQuantity, PackageQuantity, UnitOfMeasure
                    FROM Materials WHERE MaterialId = @id";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("id", materialId.Value);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            tbMaterialName.Text = reader["MaterialName"].ToString();
                            cbMaterialType.SelectedValue = reader["MaterialTypeId"];
                            tbPrice.Text = reader["UnitCost"].ToString();
                            tbStockQuantity.Text = reader["StockQuantity"].ToString();
                            tbMinimalQuantity.Text = reader["MinStockQuantity"].ToString();
                            tbPackageQuantity.Text = reader["PackageQuantity"].ToString();
                            tbUnitOfMeasure.Text = reader["UnitOfMeasure"].ToString();
                        }
                    }
                }
            }
        }
        private void LoadMaterialTypes()
        {
            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT MaterialTypeId, TypeName FROM MaterialTypes";
                using (var adapter = new SqlDataAdapter(query, conn))
                {
                    DataTable typesTable = new DataTable();
                    adapter.Fill(typesTable);
                    cbMaterialType.DataSource = typesTable;
                    cbMaterialType.DisplayMember = "TypeName";
                    cbMaterialType.ValueMember = "MaterialTypeId";
                }
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = materialId.HasValue
                    ? @"UPDATE Materials SET MaterialName = @name, MaterialTypeId = @type_id, 
                        UnitCost = @price, StockQuantity = @stock, MinStockQuantity = @min_qty, 
                        PackageQuantity = @pkg_qty, UnitOfMeasure = @unit 
                        WHERE material_id = @id"
                    : @"INSERT INTO Materials (MaterialName, MaterialTypeId, UnitCost, 
                        StockQuantity, MinStockQuantity, PackageQuantity, UnitOfMeasure)
                        VALUES (@name, @type_id, @price, @stock, @min_qty, @pkg_qty, @unit)";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("name", tbMaterialName.Text);
                    cmd.Parameters.AddWithValue("type_id", cbMaterialType.SelectedValue);
                    cmd.Parameters.AddWithValue("price", Convert.ToDecimal(tbPrice.Text));
                    cmd.Parameters.AddWithValue("stock", Convert.ToDecimal(tbStockQuantity.Text));
                    cmd.Parameters.AddWithValue("min_qty", Convert.ToDecimal(tbMinimalQuantity.Text));
                    cmd.Parameters.AddWithValue("pkg_qty", Convert.ToDecimal(tbPackageQuantity.Text));
                    cmd.Parameters.AddWithValue("unit", tbUnitOfMeasure.Text);
                    if (materialId.HasValue)
                        cmd.Parameters.AddWithValue("id", materialId.Value);

                    try
                    {
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Сохранено!");
                        EditingComplete?.Invoke();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(tbMaterialName.Text))
            {
                MessageBox.Show("Укажите наименование материала.", "Ошибка ввода",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (cbMaterialType.SelectedValue == null)
            {
                MessageBox.Show("Выберите тип материала.", "Ошибка ввода",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (!decimal.TryParse(tbPrice.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Цена должна быть неотрицательным числом с двумя знаками после запятой.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (!decimal.TryParse(tbStockQuantity.Text, out decimal stock) || stock < 0)
            {
                MessageBox.Show("Количество на складе не может быть отрицательным.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (!decimal.TryParse(tbMinimalQuantity.Text, out decimal minQty) || minQty < 0)
            {
                MessageBox.Show("Минимальное количество не может быть отрицательным.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (!decimal.TryParse(tbPackageQuantity.Text, out decimal pkgQty) || pkgQty <= 0)
            {
                MessageBox.Show("Количество в упаковке должно быть положительным.",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(tbUnitOfMeasure.Text))
            {
                MessageBox.Show("Укажите единицу измерения.", "Ошибка ввода",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            MaterialsPage materialsPage = new MaterialsPage();
            materialsPage.Show();
        }
    }
}
