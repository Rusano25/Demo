﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DemoExamProject
{
    public partial class SuppliersPage : UserControl
    {
        private string connectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=MosaicDB;Integrated Security=True";
        private int materialId;
        public SuppliersPage()
        {
            InitializeComponent();
        }

        private void LoadSuppliers()
        {
            try
            {
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"
                        SELECT s.SupplierName, s.Rating, s.StartDate
                        FROM suppliers s
                        JOIN MaterialSuppliers ms ON s.SupplierId = ms.SupplierId
                        WHERE ms.MaterialId = @materialId";
                    using (var adapter = new SqlDataAdapter(query, conn))
                    {
                        adapter.SelectCommand.Parameters.AddWithValue("materialId", materialId);
                        DataTable suppliersTable = new DataTable();
                        adapter.Fill(suppliersTable);
                        dgvSuppliers.DataSource = suppliersTable;
                        dgvSuppliers.Columns["SupplierName"].HeaderText = "Наименование поставщика";
                        dgvSuppliers.Columns["Rating"].HeaderText = "Рейтинг";
                        dgvSuppliers.Columns["StartDate"].HeaderText = "Дата начала работы";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки поставщиков: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            MaterialsPage materialsPage = new MaterialsPage();
            materialsPage.Show();
        }
    }
}
